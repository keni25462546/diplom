﻿namespace sms.model
{
    public class Task
    {
        public string title;
        public string summary;
        public string deadline;
        public string priority;
        public Person responsible;

        public override string ToString() {
            return title;
        }
    }
}