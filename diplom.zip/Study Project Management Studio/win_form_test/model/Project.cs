﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace sms.model
{
    /// <summary>
    /// Класс-одиночка, хранящий данные приложения
    /// </summary>
    class Project
    {
        private static Project instance = new Project();
        private Project() { }

        public static Project getInstance() {
            if (instance == null) instance = new Project();
            return instance;
        }

        public String name = "Unnamed";
        public String coreConcept = "survive";
        public List<String> goals = new List<string>();
        public List<String> risks = new List<string>();
        public List<Person> team = new List<Person>();
        public List<Task> tasks = new List<Task>();

        public String pathToWorkspace = "C:/nowhere";
        public List<StudyManagmentStudioFile> files = new List<StudyManagmentStudioFile>();

        public void save() {
            //string json = JsonConvert.SerializeObject();
            JsonSerializer serializer = new JsonSerializer();

            serializer.Converters.Add(new JavaScriptDateTimeConverter());
            serializer.NullValueHandling = NullValueHandling.Ignore;

            using (StreamWriter sw = new StreamWriter(@instance.pathToWorkspace + "/project.json"))
            using (JsonWriter writer = new JsonTextWriter(sw))
            {
                serializer.Serialize(writer, instance);
                // {"ExpiryDate":new Date(1230375600000),"Price":0}
            }
        }

        public void load(String path) {
            if (File.Exists(@path+"project.json"))
            {
                String jsonString = File.ReadAllText(@path + "project.json");
                Project project = JsonConvert.DeserializeObject<Project>(jsonString);
                instance = project;
            }
        } 
    }
}
