﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sms.model
{
    public class StudyManagmentStudioFile
    {
        public String fullName;
        public String safeName;

        public StudyManagmentStudioFile(String fullName, String safeName) {
            this.safeName = safeName;
            this.fullName = fullName;
        }
    }
}
