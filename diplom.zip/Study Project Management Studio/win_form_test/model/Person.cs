﻿namespace sms.model
{
    public class Person
    {
        public string name;
        public string lastName;
        public string nickname;
        public int age;
        public string iconPath;
    }
}