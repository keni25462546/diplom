﻿using sms.model;
using System;
using System.Windows.Forms;
using win_form_test;

namespace sms
{
    public partial class Entrance : Form
    {
        public Entrance() => InitializeComponent();

        private void createProject_Click(object sender, EventArgs e)
        {
            string path;

            FolderBrowserDialog directory = new FolderBrowserDialog();
            if (directory.ShowDialog() == DialogResult.OK)
            {
                path = directory.SelectedPath;
                Project project = Project.getInstance();
                project.pathToWorkspace = path;
                moveToMainFrame();
            }
        }

        private void loadProject_Click(object sender, EventArgs e)
        {
            string path;

            FolderBrowserDialog directory = new FolderBrowserDialog();
            if (directory.ShowDialog() == DialogResult.OK)
            {
                path = directory.SelectedPath;
                Project project = Project.getInstance();
                project.load(path);
                moveToMainFrame();
            }
        }

        private void moveToMainFrame() {
            MainWindow main = new MainWindow();
            main.Visible = true;
            this.Visible = false;
        }
    }
}
