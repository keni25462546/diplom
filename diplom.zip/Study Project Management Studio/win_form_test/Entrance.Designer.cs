﻿namespace sms
{
    partial class Entrance
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.createProject = new System.Windows.Forms.Button();
            this.loadProject = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // createProject
            // 
            this.createProject.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.createProject.Location = new System.Drawing.Point(14, 37);
            this.createProject.Name = "createProject";
            this.createProject.Size = new System.Drawing.Size(194, 40);
            this.createProject.TabIndex = 0;
            this.createProject.Text = "Создать";
            this.createProject.UseVisualStyleBackColor = true;
            this.createProject.Click += new System.EventHandler(this.createProject_Click);
            // 
            // loadProject
            // 
            this.loadProject.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.loadProject.Location = new System.Drawing.Point(14, 83);
            this.loadProject.Name = "loadProject";
            this.loadProject.Size = new System.Drawing.Size(194, 40);
            this.loadProject.TabIndex = 1;
            this.loadProject.Text = "Загрузить";
            this.loadProject.UseVisualStyleBackColor = true;
            this.loadProject.Click += new System.EventHandler(this.loadProject_Click);
            // 
            // Entrance
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(224, 162);
            this.Controls.Add(this.loadProject);
            this.Controls.Add(this.createProject);
            this.Name = "Entrance";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Добро пожаловать!";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button createProject;
        private System.Windows.Forms.Button loadProject;
    }
}