﻿using System;
using System.Windows.Forms;
using sms.model;
using System.IO;
using sms.view.support;

namespace sms.view
{
    public partial class ExecutionPanel : UserControl
    {
        public ExecutionPanel()
        {
            InitializeComponent();
            foreach(Task task in Project.getInstance().tasks)
            {
                taskBox.Items.Add(task);
            }
            foreach (StudyManagmentStudioFile file in Project.getInstance().files)
            {
                filesystem.Controls.Add(new FileTile(file, this));
            }
        }

        private void loadButon_Click(object sender, EventArgs e)
        {
            string path = null;

            OpenFileDialog file = new OpenFileDialog();
            if (file.ShowDialog() == DialogResult.OK)
            {
                path = file.FileName;
            }
            if (path != null)
            {
                if (!File.Exists(Project.getInstance().pathToWorkspace + file.SafeFileName))
                {
                    File.Copy(path, Project.getInstance().pathToWorkspace + file.SafeFileName);
                    StudyManagmentStudioFile workspaceFile = new StudyManagmentStudioFile(Project.getInstance().pathToWorkspace+ file.SafeFileName, file.SafeFileName);
                    filesystem.Controls.Add(new FileTile(workspaceFile, this));
                    Project.getInstance().files.Add(workspaceFile);
                } 
            }
        }

        public void readfiles(String from, String to)
        {
            string[] filePaths = Directory.GetFiles(from);
            foreach (var filename in filePaths)
            {
                string file = filename.ToString();

                //Do your job with "file"

                string str = to + file.ToString();
                if (!File.Exists(str))
                {
                    File.Copy(file, str);
                }
            }
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            Project project = Project.getInstance();
            project.save();
        }

        public void removeTile(FileTile tile) {
            filesystem.Controls.Remove(tile);
        }
    }
}
