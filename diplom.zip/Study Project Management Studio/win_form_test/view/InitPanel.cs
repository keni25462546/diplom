﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using sms.view.modal;
using sms.model;

namespace sms
{
    public partial class InitPanel : UserControl
    {
        public InitPanel()
        {
            InitializeComponent();
            updateTeamList(Project.getInstance().team);
            Project project = Project.getInstance();
            nameField.Text = project.name;
            keyConceptField.Text = project.coreConcept;
            foreach (String goal in project.goals) goalBox.Items.Add(goal);
            foreach (String risk in project.risks) riskBox.Items.Add(risk);
        }

        private void addButton_Click(object sender, EventArgs e)
        {
            CreatePersonModalFrame personCreatorFrame = new CreatePersonModalFrame(this);
            personCreatorFrame.Visible = true;
        }

        public void updateTeamList(List<Person> people) {
            teamView.Items.Clear();
            foreach (Person member in people)
            {
                teamView.Items.Add(member.nickname);
            }
        }

        private void deleteButton_Click(object sender, EventArgs e)
        {
            Project.getInstance().team.RemoveAt(teamView.SelectedIndex);
            updateTeamList(Project.getInstance().team);
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            Project project = Project.getInstance();
            project.name = nameField.Text;
            project.coreConcept = keyConceptField.Text;
            project.save();
        }

        private void addGoal_Click(object sender, EventArgs e)
        {
            InsertStringDialog goalInserter = new InsertStringDialog("Добавьте цель!");
            if (goalInserter.ShowDialog() == DialogResult.OK) {
                goalBox.Items.Add(goalInserter.answer);
                Project.getInstance().goals.Add(goalInserter.answer);
            }
        }

        private void removeGoal_Click(object sender, EventArgs e)
        {   if (goalBox.SelectedIndex >= 0)
            {
                Project.getInstance().goals.RemoveAt(goalBox.SelectedIndex);
                goalBox.Items.RemoveAt(goalBox.SelectedIndex);
            }
        }

        private void addRisk_Click(object sender, EventArgs e)
        {
            InsertStringDialog riskDefiner = new InsertStringDialog("Определите риск:");
            if (riskDefiner.ShowDialog() == DialogResult.OK)
            {
                riskBox.Items.Add(riskDefiner.answer);
                Project.getInstance().risks.Add(riskDefiner.answer);
            }
        }

        private void removeRisk_Click(object sender, EventArgs e)
        {
            if (riskBox.SelectedIndex >= 0)
            {
                Project.getInstance().goals.RemoveAt(goalBox.SelectedIndex);
                riskBox.Items.RemoveAt(goalBox.SelectedIndex);
            }
        }
    }
}
