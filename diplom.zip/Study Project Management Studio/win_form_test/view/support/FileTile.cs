﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;
using sms.model;

namespace sms.view.support
{
    public partial class FileTile : UserControl
    {
        String filepath;
        StudyManagmentStudioFile file;

        bool isSelected = false;
        ExecutionPanel parent;

        public FileTile(StudyManagmentStudioFile file, ExecutionPanel parent)
        {
            InitializeComponent();
            this.file = file;
            this.parent = parent;
            filepath = file.fullName;
            nameLabel.Text = file.safeName;
            string iconFilePath = Image.FromFile(Application.StartupPath + @"\res\file_icon.png", true).ToString();
            Console.WriteLine("1: " + iconFilePath);
            string icon_path = Application.StartupPath + @"\res\file_icon.png";
            fillPictureBox(iconBox, new Bitmap(icon_path));
        }

        public void fillPictureBox(PictureBox pbox, Bitmap bmp)
        {
            pbox.SizeMode = PictureBoxSizeMode.Normal;
            bool source_is_wider = (float)bmp.Width / bmp.Height > (float)pbox.Width / pbox.Height;

            Bitmap resized = new Bitmap(pbox.Width, pbox.Height);
            Graphics g = Graphics.FromImage(resized);
            Rectangle dest_rect = new Rectangle(0, 0, pbox.Width, pbox.Height);
            Rectangle src_rect;

            if (source_is_wider)
            {
                float size_ratio = (float)pbox.Height / bmp.Height;
                int sample_width = (int)(pbox.Width / size_ratio);
                src_rect = new Rectangle((bmp.Width - sample_width) / 2, 0, sample_width, bmp.Height);
            }
            else
            {
                float size_ratio = (float)pbox.Width / bmp.Width;
                int sample_height = (int)(pbox.Height / size_ratio);
                src_rect = new Rectangle(0, (bmp.Height - sample_height) / 2, bmp.Width, sample_height);
            }

            g.DrawImage(bmp, dest_rect, src_rect, GraphicsUnit.Pixel);
            g.Dispose();

            pbox.Image = resized;
        }

        private void FileTile_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            Process.Start(@filepath);
        }

        private void FileTile_MouseEnter(object sender, EventArgs e)
        {
            if (false)
                this.BorderStyle = BorderStyle.Fixed3D;
        }

        private void FileTile_MouseLeave(object sender, EventArgs e)
        {
            if(false)
            this.BorderStyle = BorderStyle.None;
        }

        private void FileTile_MouseClick(object sender, MouseEventArgs e)
        {
            if (!isSelected)
            {
                isSelected = true;
                this.BorderStyle = BorderStyle.Fixed3D;
            }
            else {
                isSelected = false;
                this.BorderStyle = BorderStyle.None;
            }
        }

        private void iconBox_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            Process.Start(@filepath);
        }

        private void remove_Click(object sender, EventArgs e)
        {
            File.Delete(filepath);
            Project.getInstance().files.Remove(file);
            parent.removeTile(this);
        }
    }
}
