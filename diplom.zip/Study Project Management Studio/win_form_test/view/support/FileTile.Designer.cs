﻿namespace sms.view.support
{
    partial class FileTile
    {
        /// <summary> 
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.nameLabel = new System.Windows.Forms.Label();
            this.iconBox = new System.Windows.Forms.PictureBox();
            this.remove = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.iconBox)).BeginInit();
            this.SuspendLayout();
            // 
            // nameLabel
            // 
            this.nameLabel.Location = new System.Drawing.Point(-3, 42);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(53, 13);
            this.nameLabel.TabIndex = 0;
            this.nameLabel.Text = "name";
            // 
            // iconBox
            // 
            this.iconBox.Location = new System.Drawing.Point(3, 3);
            this.iconBox.Name = "iconBox";
            this.iconBox.Size = new System.Drawing.Size(32, 32);
            this.iconBox.TabIndex = 1;
            this.iconBox.TabStop = false;
            this.iconBox.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.iconBox_MouseDoubleClick);
            // 
            // remove
            // 
            this.remove.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.remove.Location = new System.Drawing.Point(36, 3);
            this.remove.Name = "remove";
            this.remove.Size = new System.Drawing.Size(19, 20);
            this.remove.TabIndex = 2;
            this.remove.Text = "x";
            this.remove.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.remove.UseVisualStyleBackColor = false;
            this.remove.Click += new System.EventHandler(this.remove_Click);
            // 
            // FileTile
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.remove);
            this.Controls.Add(this.iconBox);
            this.Controls.Add(this.nameLabel);
            this.Name = "FileTile";
            this.Size = new System.Drawing.Size(55, 55);
            this.MouseClick += new System.Windows.Forms.MouseEventHandler(this.FileTile_MouseClick);
            this.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.FileTile_MouseDoubleClick);
            this.MouseEnter += new System.EventHandler(this.FileTile_MouseEnter);
            this.MouseLeave += new System.EventHandler(this.FileTile_MouseLeave);
            ((System.ComponentModel.ISupportInitialize)(this.iconBox)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label nameLabel;
        private System.Windows.Forms.PictureBox iconBox;
        private System.Windows.Forms.Button remove;
    }
}
