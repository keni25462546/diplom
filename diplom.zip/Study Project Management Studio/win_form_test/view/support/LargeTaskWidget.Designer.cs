﻿namespace sms.view.support
{
    partial class LargeTaskWidget
    {
        /// <summary> 
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.hr = new System.Windows.Forms.Label();
            this.nameLabel = new System.Windows.Forms.Label();
            this.dateLabel = new System.Windows.Forms.Label();
            this.priorityLabel = new System.Windows.Forms.Label();
            this.username = new System.Windows.Forms.Label();
            this.userProfilePicBox = new System.Windows.Forms.PictureBox();
            this.summaryBox = new System.Windows.Forms.Label();
            this.closeButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.userProfilePicBox)).BeginInit();
            this.SuspendLayout();
            // 
            // hr
            // 
            this.hr.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.hr.Location = new System.Drawing.Point(0, 20);
            this.hr.Name = "hr";
            this.hr.Size = new System.Drawing.Size(536, 2);
            this.hr.TabIndex = 0;
            // 
            // nameLabel
            // 
            this.nameLabel.AutoSize = true;
            this.nameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.nameLabel.Location = new System.Drawing.Point(6, 3);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(49, 16);
            this.nameLabel.TabIndex = 1;
            this.nameLabel.Text = "Name";
            // 
            // dateLabel
            // 
            this.dateLabel.AutoSize = true;
            this.dateLabel.Location = new System.Drawing.Point(358, 5);
            this.dateLabel.Name = "dateLabel";
            this.dateLabel.Size = new System.Drawing.Size(30, 13);
            this.dateLabel.TabIndex = 2;
            this.dateLabel.Text = "Date";
            // 
            // priorityLabel
            // 
            this.priorityLabel.AutoSize = true;
            this.priorityLabel.Location = new System.Drawing.Point(458, 5);
            this.priorityLabel.Name = "priorityLabel";
            this.priorityLabel.Size = new System.Drawing.Size(38, 13);
            this.priorityLabel.TabIndex = 3;
            this.priorityLabel.Text = "Priority";
            // 
            // username
            // 
            this.username.AutoSize = true;
            this.username.Location = new System.Drawing.Point(461, 38);
            this.username.Name = "username";
            this.username.Size = new System.Drawing.Size(55, 13);
            this.username.TabIndex = 5;
            this.username.Text = "Username";
            // 
            // userProfilePicBox
            // 
            this.userProfilePicBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.userProfilePicBox.Location = new System.Drawing.Point(394, 27);
            this.userProfilePicBox.Name = "userProfilePicBox";
            this.userProfilePicBox.Size = new System.Drawing.Size(61, 35);
            this.userProfilePicBox.TabIndex = 6;
            this.userProfilePicBox.TabStop = false;
            // 
            // summaryBox
            // 
            this.summaryBox.AutoSize = true;
            this.summaryBox.Location = new System.Drawing.Point(9, 27);
            this.summaryBox.MaximumSize = new System.Drawing.Size(379, 35);
            this.summaryBox.MinimumSize = new System.Drawing.Size(379, 35);
            this.summaryBox.Name = "summaryBox";
            this.summaryBox.Size = new System.Drawing.Size(379, 35);
            this.summaryBox.TabIndex = 7;
            // 
            // closeButton
            // 
            this.closeButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.closeButton.Location = new System.Drawing.Point(514, 0);
            this.closeButton.Name = "closeButton";
            this.closeButton.Size = new System.Drawing.Size(19, 19);
            this.closeButton.TabIndex = 8;
            this.closeButton.Text = "—";
            this.closeButton.UseVisualStyleBackColor = false;
            this.closeButton.Click += new System.EventHandler(this.closeButton_Click);
            // 
            // LargeTaskWidget
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.Controls.Add(this.closeButton);
            this.Controls.Add(this.summaryBox);
            this.Controls.Add(this.userProfilePicBox);
            this.Controls.Add(this.username);
            this.Controls.Add(this.priorityLabel);
            this.Controls.Add(this.dateLabel);
            this.Controls.Add(this.nameLabel);
            this.Controls.Add(this.hr);
            this.Name = "LargeTaskWidget";
            this.Size = new System.Drawing.Size(536, 65);
            ((System.ComponentModel.ISupportInitialize)(this.userProfilePicBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label hr;
        private System.Windows.Forms.Label nameLabel;
        private System.Windows.Forms.Label dateLabel;
        private System.Windows.Forms.Label priorityLabel;
        private System.Windows.Forms.Label username;
        private System.Windows.Forms.PictureBox userProfilePicBox;
        private System.Windows.Forms.Label summaryBox;
        private System.Windows.Forms.Button closeButton;
    }
}
