﻿using sms.model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sms.view.modal
{
    public partial class CreatePersonModalFrame : Form
    {
        Person person = new Person();
        InitPanel parent;

        public CreatePersonModalFrame(InitPanel parent)
        {
            this.parent = parent;
            InitializeComponent();
        }

        private void acceptButton_Click(object sender, EventArgs e)
        {
            person.name = nameField.Text;
            person.lastName = lastNameField.Text;
            person.nickname = nickNameField.Text;
            int.TryParse(ageField.Text, out person.age);
            Project.getInstance().team.Add(person);
            parent.updateTeamList(Project.getInstance().team);

            this.Close();
        }

        private void declineButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void uploadPictureButton_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            // image filters  
            open.Filter = "Image Files(*.jpg; *.jpeg; *.gif; *.bmp)|*.jpg; *.jpeg; *.gif; *.bmp";
            if (open.ShowDialog() == DialogResult.OK)
            {
                // display image in picture box  
                fillPictureBox(pictureBox, new Bitmap(open.FileName));
                Console.WriteLine(open.FileName);
                // image file path  
                person.iconPath = open.FileName;
            }
        }

        public void fillPictureBox(PictureBox pbox, Bitmap bmp)
        {
            pbox.SizeMode = PictureBoxSizeMode.Normal;
            bool source_is_wider = (float)bmp.Width / bmp.Height > (float)pbox.Width / pbox.Height;

            Bitmap resized = new Bitmap(pbox.Width, pbox.Height);
            Graphics g = Graphics.FromImage(resized);
            Rectangle dest_rect = new Rectangle(0, 0, pbox.Width, pbox.Height);
            Rectangle src_rect;

            if (source_is_wider)
            {
                float size_ratio = (float)pbox.Height / bmp.Height;
                int sample_width = (int)(pbox.Width / size_ratio);
                src_rect = new Rectangle((bmp.Width - sample_width) / 2, 0, sample_width, bmp.Height);
            }
            else
            {
                float size_ratio = (float)pbox.Width / bmp.Width;
                int sample_height = (int)(pbox.Height / size_ratio);
                src_rect = new Rectangle(0, (bmp.Height - sample_height) / 2, bmp.Width, sample_height);
            }

            g.DrawImage(bmp, dest_rect, src_rect, GraphicsUnit.Pixel);
            g.Dispose();

            pbox.Image = resized;
        }
    }
}
