﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sms.view.modal
{
    public partial class InsertStringDialog : Form
    {
        public String answer;

        public InsertStringDialog(String question)
        {
            InitializeComponent();
            textLabel.Text = question;
        }

        private void okButton_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
            this.answer = textBox.Text;
            this.Close();
        }

        private void nopeButton_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }
    }
}
