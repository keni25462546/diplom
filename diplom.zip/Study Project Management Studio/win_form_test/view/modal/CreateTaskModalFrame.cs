﻿using sms.model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace sms.view.modal
{
    public partial class CreateTaskModalFrame : Form
    {
        PlanningPanel parent;
        public CreateTaskModalFrame(PlanningPanel parent)
        {
            this.parent = parent;
            InitializeComponent();
            foreach (Person person in Project.getInstance().team) {
                responsibleChooser.Items.Add(person.nickname);
            }
        }

        private void acceptButton_Click(object sender, EventArgs e)
        {
            Task task = new Task();
            task.title = titleField.Text;
            task.deadline = dateTimePicker.Value.ToShortDateString();
            task.priority = priorityBox.SelectedItem.ToString();
            task.summary = summaryBox.Text;
            foreach (Person teammate in Project.getInstance().team)
            {
                if (responsibleChooser.SelectedItem.ToString().Equals(teammate.nickname)){
                    task.responsible = teammate;
                }
            }
            Project.getInstance().tasks.Add(task);
            parent.updateTaskList(Project.getInstance().tasks);
            Close();
        }

        private void declineButton_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
