﻿namespace sms.view
{
    partial class PlanningPanel
    {
        /// <summary> 
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.addTask = new System.Windows.Forms.Button();
            this.saveButton = new System.Windows.Forms.Button();
            this.taskLabel = new System.Windows.Forms.Label();
            this.taskBox = new System.Windows.Forms.FlowLayoutPanel();
            this.SuspendLayout();
            // 
            // addTask
            // 
            this.addTask.Location = new System.Drawing.Point(404, 30);
            this.addTask.Name = "addTask";
            this.addTask.Size = new System.Drawing.Size(66, 30);
            this.addTask.TabIndex = 1;
            this.addTask.Text = "Добавить";
            this.addTask.UseVisualStyleBackColor = true;
            this.addTask.Click += new System.EventHandler(this.addTask_Click);
            // 
            // saveButton
            // 
            this.saveButton.Location = new System.Drawing.Point(476, 30);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(83, 30);
            this.saveButton.TabIndex = 3;
            this.saveButton.Text = "Сохранить";
            this.saveButton.UseVisualStyleBackColor = true;
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // taskLabel
            // 
            this.taskLabel.AutoSize = true;
            this.taskLabel.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.taskLabel.Location = new System.Drawing.Point(18, 30);
            this.taskLabel.Name = "taskLabel";
            this.taskLabel.Size = new System.Drawing.Size(107, 30);
            this.taskLabel.TabIndex = 4;
            this.taskLabel.Text = "Задачи:";
            // 
            // taskBox
            // 
            this.taskBox.AutoScroll = true;
            this.taskBox.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.taskBox.Location = new System.Drawing.Point(23, 73);
            this.taskBox.Name = "taskBox";
            this.taskBox.Size = new System.Drawing.Size(535, 376);
            this.taskBox.TabIndex = 5;
            // 
            // PlanningPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.taskBox);
            this.Controls.Add(this.taskLabel);
            this.Controls.Add(this.saveButton);
            this.Controls.Add(this.addTask);
            this.Name = "PlanningPanel";
            this.Size = new System.Drawing.Size(583, 463);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button addTask;
        private System.Windows.Forms.Button saveButton;
        private System.Windows.Forms.Label taskLabel;
        private System.Windows.Forms.FlowLayoutPanel taskBox;
    }
}
