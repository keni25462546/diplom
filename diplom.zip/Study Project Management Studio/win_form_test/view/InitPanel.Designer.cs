﻿namespace sms
{
    partial class InitPanel
    {
        /// <summary> 
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.nameField = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.keyConceptField = new System.Windows.Forms.RichTextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.teamView = new System.Windows.Forms.ListBox();
            this.addGoal = new System.Windows.Forms.Button();
            this.removeGoal = new System.Windows.Forms.Button();
            this.removeRisk = new System.Windows.Forms.Button();
            this.addRisk = new System.Windows.Forms.Button();
            this.addButton = new System.Windows.Forms.Button();
            this.deleteButton = new System.Windows.Forms.Button();
            this.saveButton = new System.Windows.Forms.Button();
            this.goalBox = new System.Windows.Forms.ListBox();
            this.riskBox = new System.Windows.Forms.ListBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(8, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(118, 19);
            this.label1.TabIndex = 0;
            this.label1.Text = "Имя проекта:";
            // 
            // nameField
            // 
            this.nameField.Location = new System.Drawing.Point(132, 26);
            this.nameField.Name = "nameField";
            this.nameField.Size = new System.Drawing.Size(247, 20);
            this.nameField.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(8, 65);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(107, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Ключевая идея:";
            // 
            // keyConceptField
            // 
            this.keyConceptField.Location = new System.Drawing.Point(12, 85);
            this.keyConceptField.Name = "keyConceptField";
            this.keyConceptField.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
            this.keyConceptField.Size = new System.Drawing.Size(366, 80);
            this.keyConceptField.TabIndex = 3;
            this.keyConceptField.Text = "";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(8, 188);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 17);
            this.label3.TabIndex = 5;
            this.label3.Text = "Цели:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(9, 326);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 17);
            this.label4.TabIndex = 6;
            this.label4.Text = "Риски:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.teamView);
            this.groupBox1.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox1.Location = new System.Drawing.Point(385, 25);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(184, 360);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Команда";
            // 
            // teamView
            // 
            this.teamView.FormattingEnabled = true;
            this.teamView.ItemHeight = 17;
            this.teamView.Location = new System.Drawing.Point(5, 22);
            this.teamView.Name = "teamView";
            this.teamView.Size = new System.Drawing.Size(173, 327);
            this.teamView.TabIndex = 0;
            // 
            // addGoal
            // 
            this.addGoal.Location = new System.Drawing.Point(311, 184);
            this.addGoal.Name = "addGoal";
            this.addGoal.Size = new System.Drawing.Size(29, 21);
            this.addGoal.TabIndex = 9;
            this.addGoal.Text = "+";
            this.addGoal.UseVisualStyleBackColor = true;
            this.addGoal.Click += new System.EventHandler(this.addGoal_Click);
            // 
            // removeGoal
            // 
            this.removeGoal.Location = new System.Drawing.Point(346, 184);
            this.removeGoal.Name = "removeGoal";
            this.removeGoal.Size = new System.Drawing.Size(30, 21);
            this.removeGoal.TabIndex = 10;
            this.removeGoal.Text = "-";
            this.removeGoal.UseVisualStyleBackColor = true;
            this.removeGoal.Click += new System.EventHandler(this.removeGoal_Click);
            // 
            // removeRisk
            // 
            this.removeRisk.Location = new System.Drawing.Point(346, 320);
            this.removeRisk.Name = "removeRisk";
            this.removeRisk.Size = new System.Drawing.Size(30, 21);
            this.removeRisk.TabIndex = 12;
            this.removeRisk.Text = "-";
            this.removeRisk.UseVisualStyleBackColor = true;
            this.removeRisk.Click += new System.EventHandler(this.removeRisk_Click);
            // 
            // addRisk
            // 
            this.addRisk.Location = new System.Drawing.Point(311, 320);
            this.addRisk.Name = "addRisk";
            this.addRisk.Size = new System.Drawing.Size(29, 21);
            this.addRisk.TabIndex = 11;
            this.addRisk.Text = "+";
            this.addRisk.UseVisualStyleBackColor = true;
            this.addRisk.Click += new System.EventHandler(this.addRisk_Click);
            // 
            // addButton
            // 
            this.addButton.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.addButton.Location = new System.Drawing.Point(388, 390);
            this.addButton.Name = "addButton";
            this.addButton.Size = new System.Drawing.Size(81, 21);
            this.addButton.TabIndex = 13;
            this.addButton.Text = "Добавить";
            this.addButton.UseVisualStyleBackColor = true;
            this.addButton.Click += new System.EventHandler(this.addButton_Click);
            // 
            // deleteButton
            // 
            this.deleteButton.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.deleteButton.Location = new System.Drawing.Point(477, 390);
            this.deleteButton.Name = "deleteButton";
            this.deleteButton.Size = new System.Drawing.Size(91, 21);
            this.deleteButton.TabIndex = 14;
            this.deleteButton.Text = "Удалить";
            this.deleteButton.UseVisualStyleBackColor = true;
            this.deleteButton.Click += new System.EventHandler(this.deleteButton_Click);
            // 
            // saveButton
            // 
            this.saveButton.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.saveButton.Location = new System.Drawing.Point(385, 417);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(183, 28);
            this.saveButton.TabIndex = 15;
            this.saveButton.Text = "Сохранить";
            this.saveButton.UseVisualStyleBackColor = true;
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // goalBox
            // 
            this.goalBox.FormattingEnabled = true;
            this.goalBox.Location = new System.Drawing.Point(11, 208);
            this.goalBox.Name = "goalBox";
            this.goalBox.Size = new System.Drawing.Size(365, 95);
            this.goalBox.TabIndex = 16;
            // 
            // riskBox
            // 
            this.riskBox.FormattingEnabled = true;
            this.riskBox.Location = new System.Drawing.Point(11, 347);
            this.riskBox.Name = "riskBox";
            this.riskBox.Size = new System.Drawing.Size(364, 95);
            this.riskBox.TabIndex = 17;
            // 
            // InitPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.Controls.Add(this.riskBox);
            this.Controls.Add(this.goalBox);
            this.Controls.Add(this.saveButton);
            this.Controls.Add(this.deleteButton);
            this.Controls.Add(this.addButton);
            this.Controls.Add(this.removeRisk);
            this.Controls.Add(this.addRisk);
            this.Controls.Add(this.removeGoal);
            this.Controls.Add(this.addGoal);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.keyConceptField);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.nameField);
            this.Controls.Add(this.label1);
            this.Name = "InitPanel";
            this.Size = new System.Drawing.Size(583, 463);
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox nameField;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RichTextBox keyConceptField;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button addGoal;
        private System.Windows.Forms.Button removeGoal;
        private System.Windows.Forms.Button removeRisk;
        private System.Windows.Forms.Button addRisk;
        private System.Windows.Forms.Button addButton;
        private System.Windows.Forms.Button deleteButton;
        private System.Windows.Forms.Button saveButton;
        private System.Windows.Forms.ListBox teamView;
        private System.Windows.Forms.ListBox goalBox;
        private System.Windows.Forms.ListBox riskBox;
    }
}
