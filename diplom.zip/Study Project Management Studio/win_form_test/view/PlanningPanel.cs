﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using sms.view.support;
using sms.view.modal;
using sms.model;

namespace sms.view
{
    public partial class PlanningPanel : UserControl
    {
        public PlanningPanel()
        {
            InitializeComponent();
            updateTaskList(Project.getInstance().tasks);
        }

        private void addTask_Click(object sender, EventArgs e)
        {
            CreateTaskModalFrame createTask = new CreateTaskModalFrame(this);
            createTask.Visible = true;
        }

        public void updateTaskList(List<Task> tasks) {
            taskBox.Controls.Clear();
            foreach (Task task in tasks) {
                taskBox.Controls.Add(new LargeTaskWidget(task, this));
            }
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            Project.getInstance().save();
        }
    }
}
