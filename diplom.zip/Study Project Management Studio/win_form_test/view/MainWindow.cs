﻿using sms;
using sms.view;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace win_form_test
{
    public partial class MainWindow : Form
    {
        public MainWindow() => InitializeComponent();

        private void MainWindow_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void initButton_Click(object sender, EventArgs e)
        {
            contentPane.Controls.Clear();
            contentPane.Controls.Add(new InitPanel());
        }

        private void planningButton_Click(object sender, EventArgs e)
        {
            contentPane.Controls.Clear();
            contentPane.Controls.Add(new PlanningPanel());
        }

        private void executeButton_Click(object sender, EventArgs e)
        {
            contentPane.Controls.Clear();
            contentPane.Controls.Add(new ExecutionPanel());
        }
    }
}
