﻿namespace win_form_test
{
    partial class MainWindow
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.navigationPane = new System.Windows.Forms.Panel();
            this.executeButton = new System.Windows.Forms.Button();
            this.planningButton = new System.Windows.Forms.Button();
            this.initButton = new System.Windows.Forms.Button();
            this.contentPane = new System.Windows.Forms.Panel();
            this.navigationPane.SuspendLayout();
            this.SuspendLayout();
            // 
            // navigationPane
            // 
            this.navigationPane.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.navigationPane.Controls.Add(this.executeButton);
            this.navigationPane.Controls.Add(this.planningButton);
            this.navigationPane.Controls.Add(this.initButton);
            this.navigationPane.Location = new System.Drawing.Point(0, -1);
            this.navigationPane.Name = "navigationPane";
            this.navigationPane.Size = new System.Drawing.Size(204, 465);
            this.navigationPane.TabIndex = 0;
            // 
            // executeButton
            // 
            this.executeButton.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.executeButton.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.executeButton.Location = new System.Drawing.Point(2, 87);
            this.executeButton.Name = "executeButton";
            this.executeButton.Size = new System.Drawing.Size(198, 40);
            this.executeButton.TabIndex = 2;
            this.executeButton.Text = "Исполнение";
            this.executeButton.UseVisualStyleBackColor = true;
            this.executeButton.Click += new System.EventHandler(this.executeButton_Click);
            // 
            // planningButton
            // 
            this.planningButton.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.planningButton.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.planningButton.Location = new System.Drawing.Point(2, 45);
            this.planningButton.Name = "planningButton";
            this.planningButton.Size = new System.Drawing.Size(198, 40);
            this.planningButton.TabIndex = 1;
            this.planningButton.Text = "Планирование";
            this.planningButton.UseVisualStyleBackColor = true;
            this.planningButton.Click += new System.EventHandler(this.planningButton_Click);
            // 
            // initButton
            // 
            this.initButton.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.initButton.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.initButton.Location = new System.Drawing.Point(2, 3);
            this.initButton.Name = "initButton";
            this.initButton.Size = new System.Drawing.Size(198, 40);
            this.initButton.TabIndex = 0;
            this.initButton.Text = "Инициализация";
            this.initButton.UseVisualStyleBackColor = true;
            this.initButton.Click += new System.EventHandler(this.initButton_Click);
            // 
            // contentPane
            // 
            this.contentPane.Location = new System.Drawing.Point(205, 0);
            this.contentPane.Name = "contentPane";
            this.contentPane.Size = new System.Drawing.Size(583, 463);
            this.contentPane.TabIndex = 1;
            // 
            // MainWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 462);
            this.Controls.Add(this.contentPane);
            this.Controls.Add(this.navigationPane);
            this.Name = "MainWindow";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Study Project Management Studio";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MainWindow_FormClosed);
            this.navigationPane.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel navigationPane;
        private System.Windows.Forms.Button executeButton;
        private System.Windows.Forms.Button planningButton;
        private System.Windows.Forms.Button initButton;
        private System.Windows.Forms.Panel contentPane;
    }
}

